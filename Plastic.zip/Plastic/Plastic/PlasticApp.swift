//
//  PlasticApp.swift
//  Plastic
//
//  Created by student on 2026/04/27.
//

import SwiftUI

@main
struct PlasticApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
